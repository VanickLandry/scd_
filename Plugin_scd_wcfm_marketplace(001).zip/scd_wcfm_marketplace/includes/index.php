<?php

//use to save the rate during a checkout order
include 'scd-wcfm-rate-saver.php';
include 'scd-wcfm-functions.php';


//controller use to correct admin and vendor dashboard
include 'admin/scd-wcfm-admin-report-by-date.php';
include 'admin/scd-wcfm-admin-store-vendors.php';
include 'admin/scd-wcfm-admin-dashboard.php';

include 'vendor/scd-wcfm-vendor-dashboard.php';
include 'vendor/scd-wcfm-vendor-ledger.php';

